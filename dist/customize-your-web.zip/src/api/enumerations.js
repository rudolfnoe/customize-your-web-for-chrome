LinkTarget = {
   "CURRENT":"CURRENT",
   "TAB":"TAB",
   "WINDOW":"WINDOW"
}