/**
 * 
 */
var start = new Date().getTime();