/**
 * 
 */
console.log('CYW init took: ' + ((new Date()).getTime() - start) + " ms");